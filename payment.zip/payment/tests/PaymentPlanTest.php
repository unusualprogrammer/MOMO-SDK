<?php
use PHPUnit\Framework\TestCase;

class PaymentPlanTest extends TestCase
{

}

?>
