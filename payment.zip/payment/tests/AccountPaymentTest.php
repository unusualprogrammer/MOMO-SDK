<?php
use PHPUnit\Framework\TestCase;

class AccountPaymentTest extends TestCase
{
   

}

?>
