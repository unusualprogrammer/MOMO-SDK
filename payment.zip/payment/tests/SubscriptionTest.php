<?php
use PHPUnit\Framework\TestCase;

class SubscriptionTest extends TestCase
{

    
}

?>
