<?php
use PHPUnit\Framework\TestCase;

class CardPaymentTest extends TestCase
{


}

?>
